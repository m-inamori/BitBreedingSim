#pragma once

namespace Int {
	using ull = unsigned long long;
}
