#pragma once

#include <vector>
#include <string>
#include <random>
#include <cstdint>
#include <Rcpp.h>

namespace GenomicsCommon {
	using Pos = int64_t;
}
