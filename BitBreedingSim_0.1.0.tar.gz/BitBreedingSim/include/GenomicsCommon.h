#pragma once

#include <vector>
#include <string>
#include <random>
#include <Rcpp.h>

namespace GenomicsCommon {
	using Pos = long long;
}
