#ifndef __INT
#define __INT

namespace Int {
	using ull = unsigned long long;
}

#endif
